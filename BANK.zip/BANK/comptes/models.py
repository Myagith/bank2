from django.contrib.auth import get_user_model

# Use the existing custom user model
Utilisateur = get_user_model()